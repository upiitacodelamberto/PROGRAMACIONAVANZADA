Directory structure
-------------------
.\         preprocessed files
source\    source files that must be preprocessed


Files
-----
.\jpp.exe                     JCL pascal preprocessor 
.\preprocess.bat              preprocess the source\JvExXxx files
.\Readme.txt                  this file
source\dpp.exe                Delphi language preprocessor (http://www.sf.net/projects/dpp32)
source\build.pas              used for preprocessing
source\JvExControls.pas       base system and interfaces
source\JvExXxx                extended VCL classes for the VCL controls
source\JvExControls.macros    macros used by the preprocessor
