The PhotoOp demo uses a Paradox database to store the data. In order to run this demo, you need to have the 
BDE installed and correctly configured. In addition, the path to the data is restricted in Paradox. 
If you get an error about the path being too long when you start the application, copy the executable and 
the \Data subfolder from the source folder to a folder with a shorter path and run the demo from that location instead.